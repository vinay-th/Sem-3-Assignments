#!/bin/sh
# 12. Write a shell script that will compress current directory and also all subdirectories, keeping the
# original files at their place.
zip -r compressed.zip ./*
