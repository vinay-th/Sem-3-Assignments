#!/bin/sh
# 5. Write a shell script that provides information about used ansd unused memory.
echo "Used memory and unused memory:"
free
