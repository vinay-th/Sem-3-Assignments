#!/bin/sh
# 1. Write a shell script that display the disk usage of files and directories on a machine.
du -a
