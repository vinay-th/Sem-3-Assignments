#!/bin/sh
# 13. Write a shell script that shows both compressed and uncompressed size of each file in the archeive along with the percentage of compression archeived.

zip -v compressed.zip
